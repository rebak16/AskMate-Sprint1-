import connection


def get_next_id():
    list_of_datas = connection.read_question_csv()
    return str(int(list_of_datas[-1]['id']) + 1)